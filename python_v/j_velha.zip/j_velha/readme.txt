Para executar o programa:

python actor_player.py

Porém, antes disso:
1. ir para a pasta src (cd src)
2. nesta pasta, execute virtualenv venv
3. ative a virtualenv: venv\Scripts\activate
3. a seguir, execute pip install -r ../requirements.txt
4. pode executar o programa (python actor_player.py)